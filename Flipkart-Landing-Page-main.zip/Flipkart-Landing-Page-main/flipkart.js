function scroll_first_section_left(){
    var left = document.querySelector('.sub_item')
    left.scrollBy(350,0)
}

function scroll_second_section_left(){
    var left = document.querySelector('.sub_item5')
    left.scrollBy(350,0)
}

function scroll_first_section_right(){
    var right = document.querySelector('.sub_item')
    right.scrollBy(-350,0)
}

function scroll_second_section_right(){
    var right = document.querySelector('.sub_item5')
    right.scrollBy(-350,0)
}
// scroll bar end