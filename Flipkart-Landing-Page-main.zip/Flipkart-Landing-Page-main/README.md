# Flipkart Landing Page

<h2>:octocat: Hey There.! :wave:</h2>
<br>
- 🔭 In this Reposetory You Will find a simple Flipkart landing page.<br><br>

<h2>Tech Stack</h2>
- This Project is Build With Some Famous Tech And Tools Which Are Mentioned Below... :point_down: <br><br>

[![My Skills](https://skillicons.dev/icons?i=html,css,js,vscode)](https://skillicons.dev) <br><br>


<h2>Screenshot</h2>
 <img style="border: 3px solid black"; src="https://user-images.githubusercontent.com/71020225/212264675-cba12623-4696-4edc-a7e1-feed3a177d86.png" alt="">
<br>

<h2>Check Live</h2>
https://samarthdadhaniya.github.io/Flipkart-Landing-Page/
<br><br>

## Connect with me:

<a href="https://www.instagram.com/"><img align="left" alt="codeSTACKr | Instagram" width="30px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" /></a>

<a href="https://www.facebook.com/"><img align="left" alt="codeSTACKr | Facebook" width="30px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/facebook.svg" /></a>

<a href="https://www.linkedin.com/in/samarth-dadhaniya-13bb04206/"><img align="left" alt="codeSTACKr | Linkdin" width="30px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" /></a>
